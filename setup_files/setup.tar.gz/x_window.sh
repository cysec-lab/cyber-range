#!/bin/sh

# X-Window install
yum -y groupinstall "Desktop" "Desktop Platform" "General Purpose Desktop" "Japanese Support"

yum -y install expect
