DELETE FROM guestbook WHERE name NOT IN ('Taro', 'Anonymous')
