create table guestbook(name varchar(30), comment varchar(50));
