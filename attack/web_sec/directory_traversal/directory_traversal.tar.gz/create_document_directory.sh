#!/bin/sh

mkdir /public
mkdir /secret
cp secret_document.txt /secret 
cp open_document.txt /public
