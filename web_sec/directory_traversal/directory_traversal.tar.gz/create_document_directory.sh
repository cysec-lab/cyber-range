#!/bin/sh

mkdir /public
mkdir /secret
mv /root/secret secret_document.txt
mv /root/public open_document.txt 
