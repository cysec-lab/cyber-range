insert into guestbook(name, comment) values
    ('Taro', 'Hello'),
    ('Jiro', 'Hacked');
