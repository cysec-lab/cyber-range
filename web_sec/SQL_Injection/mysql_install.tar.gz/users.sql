create table users(id int, name varchar(30), password varchar(50));
