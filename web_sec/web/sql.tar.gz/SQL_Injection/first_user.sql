insert into users (id, name, password) values 
    (1, 'admin', MD5('admin')),
    (2, 'Taro', MD5('roTa')),
    (3, 'Takeshi', MD5('shiTake')),
    (4, 'Mako', MD5('koMa'));
