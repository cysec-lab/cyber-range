#!/bin/sh

mkdir /public
mkdir /secret
mv /root/secret_document.txt
