create table login_users(userid int, name varchar(30), password varchar(100));
