insert into login_users(userid, name, password) values
    (1357, 'Taro', SHA1('taro')),
    (2468, 'Jiro', SHA1('jiro'));
