<html>
<body>
  <h1>掲示板</h1>
  自由に投稿してください
  <form action="" method="post">
    <p>Name</p>
    <input type="text" name="name" size="30"><br />
    <p>Message</p>
    <textarea type="text" name="message" size="50"></textarea><br />
    <input type="submit" name="submit" value="submit">
  </form>

</body>
</html>

<?php
session_start();
$user = 'root';
$password = 'cysec.lab';

try {
  $pdo = new PDO(
    'mysql:host=localhost;
    dbname=stored_db;
    charset=utf8',
    $user,
    $password
  );

  $sql = 'SELECT * FROM guestbook';
  $stmt = $pdo->query($sql);
  while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    print ('Name: '.$row['name'].'<br />');
    print ('Comment: '.$row['comment'].'<br /><br />');
  }

} catch(PDOException $e) {
  print ('Error:'.$e->getMessage());
}


if(isset($_POST['submit'])) {

  $name    = trim($_POST['name']);
  $message = trim($_POST['message']);

  #$name = mysql_real_escape_string($name);

  $message = stripslashes($message);
  #$message = mysql_real_escape_string($message);

  $sql = "INSERT INTO guestbook (name, comment) VALUES ('$name', '$message')";
  $stmt = $pdo->prepare($sql);
  $stmt->execute();

  $pdo = null;
  echo '<script type="text/javascript">window.location.href=location;</script>';
}
?>
