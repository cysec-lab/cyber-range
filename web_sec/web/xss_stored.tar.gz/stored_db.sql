create database stored_db;
