#!/bin/sh

mysql -uroot -pcysec.lab stored_db < stored_db_reset.sql
