insert into guestbook(name, comment) values 
    ('Taro', 'Hello'),
    ('Anonymous', 'Hacked');
